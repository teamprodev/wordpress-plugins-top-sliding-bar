<?php

// Require files
require_once 'widgets/tsw_login.php';
require_once 'widgets/tsw_list.php';
require_once 'widgets/tsw_article.php';
require_once 'widgets/tsw_opening.php';
require_once 'widgets/tsw_gallery_6.php';
require_once 'widgets/tsw_gallery_12.php';
require_once 'widgets/tsw_html.php';
require_once 'widgets/tsw_shortcode.php';

?>